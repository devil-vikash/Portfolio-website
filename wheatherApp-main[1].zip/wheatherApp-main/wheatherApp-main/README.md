# wheatherApp
A weather application written with JavaScript and I used apis, as well as the structure of promise, fetch, and sync-await.

# How to use :
First, download the files and open them in your system.Type your desired city in the search box and then press enter.

In the cities section, cities with the same name as that city are displayed all over the world.

And in the map section, the map of that city is displayed
